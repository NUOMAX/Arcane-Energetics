Arcane Energetics — Organized Models & Textures

Included:
- models/blockymodel/  (.blockymodel render models)
- models/blockbench/   (.bbmodel sources, if present)
- textures/            (base textures)
- textures_bleed/      (2px edge-bleed copies to reduce mip/edge bleeding)
- manifests/           (variant lookup manifests, if present)

Not included:
- icons/, previews/, catalogs/, pipeline scripts, CSV audit files.
